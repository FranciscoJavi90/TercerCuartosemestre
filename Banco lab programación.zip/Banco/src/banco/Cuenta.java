/*
Programador: Francisco Javier Cifuentes Cajas.
Id: 2590-20-10308
*/
package banco;

import java.util.Scanner;

public class Cuenta {
    Scanner entrada = new Scanner(System.in);
        private float saldo;
        private float retirar; 
         
// setter para saldo, establece el valor del saldo
        public void setSaldo(float saldo){
            this.saldo = 50;
        }        
        // Depositar
        public void depositar(float monto){
            System.out.print("Deposite: ");
            monto = entrada.nextInt();
            saldo=saldo + monto;
        }   
        public void setRetirar(float retirar){
            this.retirar =saldo; 
        }
        // Retirar
        public void retirar(float retiro){
            System.out.print("retirar: ");
            retiro = entrada.nextInt();
            saldo = saldo - retiro;
        } 
        // get de retiro
        public float getRetirar(){
            return retirar;
        }
        // getter para saldo
        public float getSaldo(){
            return saldo;
        }
        
}

/* 
        inicializar la cuenta con 50.00
        solicitar al usuario un monton a depositar y depositarlo en la cuenta.
        solicitar al usuario  un monto a retirar, y retirarlo de la cuenta.
        Mostrar en pantalla el saldo de la cuenta.
        * Agregar método y seguir la misma lógica.
        */