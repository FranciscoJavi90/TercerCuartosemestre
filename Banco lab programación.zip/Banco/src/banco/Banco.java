/*
Programador: Francisco Javier Cifuentes Cajas.
Id: 2590-20-10308
*/
package banco;
import java.util.Scanner;
public class Banco {

    public static void main(String[] args) {
        
     Scanner sn = new Scanner(System.in);
       boolean salir = false;
       int opcion; 
        
       while(!salir){
            
           System.out.println("1. Opcion 1");
           System.out.println("2. Opcion 2");
           System.out.println("3. Opcion 3");
           System.out.println("4. Salir");
            
           System.out.println("Escribe una de las opciones");
           opcion = sn.nextInt();
            
       }    
    }    
}