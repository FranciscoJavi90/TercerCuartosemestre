
package lab.pkg2;
import java.util.Scanner;
public class Lab2 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int numero, total_suma = 0;
        int num_par = 0, num_impar = 0;
        int contador = 0, num_maximo = 0, num_minimo = 1000;
        float promedio = 5;
         
        
        while(contador < 5){
            System.out.print("Ingrese un número: ");
            numero = entrada.nextInt();
            total_suma = total_suma + numero;            
        if (numero % 2==0)  {
            num_par++;
        }
        else    {
                num_impar++;
        }
        contador++;
            promedio = total_suma / promedio;
        if (numero > num_maximo) {
            num_maximo = numero;
        }
        if (numero < num_minimo) {
            num_minimo = numero;
        }
        }   
        System.out.println("El total de la suma es: " + total_suma);
        System.out.println("El total promedio es: " + promedio);
        System.out.println("Cantidad de números pares: " + num_par);
        System.out.println("Cantidad de números impares: " + num_impar);
        System.out.println("Es número máximo es: " + num_maximo);
        System.out.println("Es número mínimo: " + num_minimo);
    }    
}
/*
    Francisco Javier Cifuentes Cajas.
    carné: 2590-20-10308
*/