/*
Programador: Francisco Javier Cifuentes Cajas.
Id: 2590-20-10308
*/
package examen.corto.pkg1;
import java.util.Scanner;
public class ExamenCorto1 {

    public static void main(String[] args) {
    
    Scanner sn = new Scanner(System.in);
       boolean salir = false;
       int opcion; 
        
       while(!salir){
            
           System.out.println("1. Bomba 1");
           System.out.println("2. Bomba 2");
           System.out.println("3. salir");
            
           System.out.println("Escribe una de las opciones");
           opcion = sn.nextInt();
            
       }    
    }    
}

