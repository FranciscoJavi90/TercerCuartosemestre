/*
Programador: Francisco Javier Cifuentes Cajas.
Id: 2590-20-10308
*/
package examen.corto.pkg1;

import java.util.Scanner;

public class Gasolina {
    
Scanner Bomba = new Scanner(System.in);
        public float cantidadGasolina;
        public float bomba1 = 300;
        public float bomba2 = 300;
        public String tipoGasolina;
        
        public void setcantidadGasolina(float saldo){
            this.cantidadGasolina = 300;        
        public void setbomba1(float bomba1){
            System.out.print("Cantidad gasolina: "+bomba1);
            cantidadGasolina = Bomba.nextInt();
            cantidadGasolina=cantidadGasolina - bomba1;
        public void setbomba2 (float bomba2){
            System.out.print("Cantidad gasolina: "+bomba2);
            cantidadGasolina = Bomba.nextInt();
            cantidadGasolina=cantidadGasolina - bomba2;
}
}